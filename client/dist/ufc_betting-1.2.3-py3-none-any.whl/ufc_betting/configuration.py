host = 'localhost'
port = '5000'

URL_application = f'http://{host}:{port}'